library(testthat)
library(clampSeg)

test_check("clampSeg")